// File: utils/geocode.js

const axios = require('axios');

async function getCoordinates(county, state) {
    const geocodeUrl = `https://maps.googleapis.com/maps/api/geocode/json?address=${county},${state}&key=${process.env.GOOGLE_MAPS_API_KEY}`;
    try {
        const response = await axios.get(geocodeUrl);
        const location = response.data.results[0]?.geometry.location;
        return location ? { lat: location.lat, lng: location.lng } : null;
    } catch (error) {
        console.error('Error fetching geolocation:', error.message);
        return null;
    }
}

module.exports = { getCoordinates };
