const axios = require('axios');
const { getAccessToken } = require('./authService');

async function getLoansByCounty(state, counties) {
    try {
        const access_token = getAccessToken();
        const settings = {
            url: "https://api.elliemae.com/encompass/v1/loanPipeline",
            method: "POST",
            timeout: 0,
            params: {
                cursortype: "randomAccess",
                limit: 10
            },
            headers: {
                'Authorization': `Bearer ${access_token}`,
                'Content-Type': 'application/json'
            },
            data: {
                filter: {
                    terms: [
                        {
                            canonicalName: "Loan.LoanFolder",
                            value: "Pipeline",
                            matchType: "exact"
                        },
                        {
                            canonicalName: "Fields.1172",
                            value: "Conventional",
                            matchType: "exact"
                        },
                        {
                            canonicalName: "Fields.11",
                            matchType: "isNotEmpty"
                        },
                        {
                            canonicalName: "Fields.12",
                            matchType: "isNotEmpty"
                        },
                        {
                            canonicalName: "Fields.15",
                            matchType: "isNotEmpty"
                        }
                    ]
                },
                fields: [
                    "Loan.LoanNumber",
                    "Loan.LoanAmount",
                    "Loan.BorrowerName",
                    "Fields.4000",
                    "Fields.11",
                    "Fields.12",
                    "Fields.13",
                    "Fields.14",
                    "Fields.15"                   
                ],
                sortOrder: [
                    {
                        canonicalName: "Loan.LoanNumber",
                        order: "desc"
                    },
                    {
                        canonicalName: "Fields.4000",
                        order: "desc"
                    }
                ]
            }
        };

        const response = await axios(settings);
        return response.data;
    } catch (error) {
        console.error('Error querying Encompass Loan Pipeline:', error.message);
        throw error;
    }
}

module.exports = { getLoansByCounty };