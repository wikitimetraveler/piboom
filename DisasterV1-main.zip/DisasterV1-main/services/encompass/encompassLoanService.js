const axios = require('axios');
const { getAccessToken } = require('./authService');

async function getLoanById(loanGuid) {
    try {
        const access_token = await getAccessToken();
        const config = {
            method: 'get',
            maxBodyLength: Infinity,
            url: `https://api.elliemae.com/encompass/v1/loans/${loanGuid}`,
            headers: { 
                'Authorization': `Bearer ${access_token}`, 
                'Content-Type': 'application/json'
            }
        };

        const response = await axios(config);
        console.log('Encompass API response received'); // Debug log

        return response.data;
    } catch (error) {
        console.error('Error fetching loan from Encompass:', error.message);
        if (error.response) {
            console.error('Encompass API response:', error.response.status, error.response.data);
        }
        throw error;
    }
}

module.exports = { getLoanById }; 