const axios = require('axios');

let access_token = null;

async function initializeAuth() {
    const settings = {
        url: "https://api.elliemae.com/oauth2/v1/token",
        method: "POST",
        timeout: 0,
        headers: {
            "Content-Type": "application/x-www-form-urlencoded"
        },
        data: {
            grant_type: "password",
            username: process.env.ENCOMPASS_USERNAME,
            password: process.env.ENCOMPASS_PASSWORD,
            client_id: process.env.ENCOMPASS_CLIENT_ID,
            client_secret: process.env.ENCOMPASS_CLIENT_SECRET
        }
    };

    try {
        const response = await axios(settings);
        console.log('Auth response:', response.data);
        access_token = response.data.access_token;
        return access_token;
    } catch (error) {
        console.error('Error initializing auth:', error.message);
        throw error;
    }
}

function getAccessToken() {
    return access_token;
}

module.exports = { initializeAuth, getAccessToken }; 