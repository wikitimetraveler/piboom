const axios = require('axios');
const YOUTUBE_API_KEY = 'AIzaSyDwVl1Cpi3DBIBUoCnWrLuV2oOT7mbMnNI';
const BASE_URL = 'https://www.googleapis.com/youtube/v3';

class YouTubeService {
    async searchDisasterVideos(disasterType, startDate) {
        try {
            const searchQuery = `${disasterType} disaster`;
            const params = {
                part: 'snippet',
                q: 'Jimi Hendrix',
                key: YOUTUBE_API_KEY,
                type: 'video',
                maxResults: 5,
                order: 'date'
            };

            if (startDate) {
                params.publishedAfter = new Date(startDate).toISOString();
            }

            const response = await axios.get(`${BASE_URL}/search`, { params });

            if (!response.data || !response.data.items) {
                console.error('Invalid YouTube API response:', response.data);
                return [];
            }

            return response.data.items.map(item => ({
                id: item.id.videoId,
                title: item.snippet.title,
                description: item.snippet.description,
                thumbnail: item.snippet.thumbnails.medium,
                publishedAt: item.snippet.publishedAt
            }));
        } catch (error) {
            console.error('YouTube API Error:', error.response?.data || error.message);
            return []; // Return empty array instead of throwing
        }
    }
}

module.exports = new YouTubeService(); 