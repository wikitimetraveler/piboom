const axios = require('axios');

async function getFemaDisasters() {
    //const femaUrl = 'https://www.fema.gov/api/open/v2/DisasterDeclarationsSummaries?$filter=incidentType eq "Fire"';
    const femaUrl = 'https://www.fema.gov/api/open/v2/DisasterDeclarationsSummaries';

    try {
        const response = await axios.get(femaUrl);
        // Process the data to get active or new disasters
        const activeDisasters = response.data.DisasterDeclarationsSummaries.filter(d => !d.disasterCloseOutDate);
      //  return activeDisasters.map(d => d.designatedArea);
      // Return the entire disaster object for each active disaster
      return activeDisasters;
    } catch (error) {
        console.error('Error fetching FEMA data:', error.message);
        throw error;
    }
}

module.exports = { getFemaDisasters };
