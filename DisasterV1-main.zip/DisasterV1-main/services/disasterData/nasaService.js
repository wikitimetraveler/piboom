const axios = require('axios');
require('dotenv').config();

async function getFirmsData() {
    try {
        const NASA_API_KEY = process.env.NASA_API_KEY;
        const response = await axios.get(`https://firms.modaps.eosdis.nasa.gov/api/area/csv/${NASA_API_KEY}/VIIRS_SNPP_NRT/-125.0,24.396308,-66.93457,49.384358/2`);
        return response.data;
    } catch (error) {
        console.error('Error fetching NASA FIRMS Data:', error);
        throw error;
    }
}

module.exports = { getFirmsData };
