class DatabaseLoader {
    constructor() {
        this.nasaTable = null;
        this.femaTable = null;
        this.loanTable = null;
        this.currentMarker = null;
        this.geocodeCache = new Map();
        this.selectedDisasterInfo = null;
    }

    initialize(map) {
        this.map = map;
        this.geocoder = new google.maps.Geocoder();
    }

    async loadNasaData() {
        const nasaTableElement = document.getElementById('nasaTable');
        nasaTableElement.innerHTML = '<tr><td colspan="4">Loading...</td></tr>';
        
        try {
            const response = await fetch('https://firms.modaps.eosdis.nasa.gov/api/area/csv/c8490c740cace0baa46a19e101b81182/VIIRS_SNPP_NRT/-125.0,24.396308,-66.93457,49.384358/2');
            const csvText = await response.text();
            const data = this._parseNasaData(csvText);
            this.nasaTable = this._initializeNasaTable(nasaTableElement, data);
            this._addNasaClickHandler();
            return this.nasaTable;
        } catch (error) {
            console.error('Error fetching NASA Fire Data:', error);
            nasaTableElement.innerHTML = '<tr><td colspan="4">Error fetching data.</td></tr>';
            throw error;
        }
    }

    async loadFemaData() {
        const femaTableElement = document.getElementById('femaTable');
        femaTableElement.innerHTML = '<tr><td colspan="11">Loading...</td></tr>';

        try {
            const response = await fetch('/api/fema-disasters');
            const data = await response.json();
            this.femaTable = this._initializeFemaTable(femaTableElement, data);
            this._addFemaClickHandler();
            return this.femaTable;
        } catch (error) {
            console.error('Error fetching FEMA Data:', error);
            femaTableElement.innerHTML = '<tr><td colspan="11">Error fetching data.</td></tr>';
            throw error;
        }
    }

    async loadLoanData(state, county) {
        const loanTableElement = document.getElementById('loanTable');
        loanTableElement.innerHTML = '<tr><td colspan="4">Loading...</td></tr>';

        try {
            const response = await fetch(`/api/loans/${state}/${encodeURIComponent(county)}`);
            const data = await response.json();
            this.loanTable = this._initializeLoanTable(loanTableElement, data);
            this._addLoanClickHandler();
            return this.loanTable;
        } catch (error) {
            console.error('Error fetching Loan Data:', error);
            loanTableElement.innerHTML = '<tr><td colspan="4">Error fetching data.</td></tr>';
            throw error;
        }
    }

    // Private helper methods
    _parseNasaData(csvText) {
        const lines = csvText.split('\n');
        const headers = lines[0].split(',');
        return lines.slice(1, 21)
            .filter(line => line.trim())
            .map(line => {
                const values = line.split(',');
                return headers.reduce((obj, header, index) => {
                    obj[header.trim()] = values[index];
                    obj.county = 'Loading...';
                    obj.state = 'Loading...';
                    return obj;
                }, {});
            });
    }

    _initializeNasaTable(element, data) {
        if ($.fn.DataTable.isDataTable(element)) {
            $(element).DataTable().clear().destroy();
        }

        return $(element).DataTable({
            data: data,
            columns: [
                { data: 'county', title: 'County' },
                { data: 'state', title: 'State' },
                { data: 'latitude', title: 'Latitude' },
                { data: 'longitude', title: 'Longitude' },
                { data: 'confidence', title: 'Confidence' },
                { data: 'acq_date', title: 'Date' }
            ],
            responsive: true,
            dom: 'Bfrtip',
            buttons: ['copy', 'csv', 'excel', 'pdf', 'print'],
            pageLength: 10
        });
    }

    _initializeFemaTable(element, data) {
        if ($.fn.DataTable.isDataTable(element)) {
            $(element).DataTable().clear().destroy();
        }

        return $(element).DataTable({
            data: data,
            columns: [
                { data: 'declarationType', title: 'Declaration Type' },
                { data: 'incidentType', title: 'Incident Type' },
                { data: 'declarationTitle', title: 'Declaration Title' },
                { 
                    data: 'designatedArea', 
                    title: 'County',
                    render: (data) => data.replace(/\s*\(County\)/i, '')
                },
                { data: 'state', title: 'State' },
                { data: 'incidentBeginDate', title: 'Incident Begin Date' },
                { 
                    data: 'incidentEndDate', 
                    title: 'Incident End Date',
                    render: (data) => (data || 'Ongoing') 
                }
            ],
            responsive: true,
            dom: 'Bfrtip',
            buttons: ['copy', 'csv', 'excel', 'pdf', 'print']
        });
    }

    _initializeLoanTable(element, data) {
        if ($.fn.DataTable.isDataTable(element)) {
            $(element).DataTable().clear().destroy();
        }

        return $(element).DataTable({
            data: data,
            columns: [
                { data: 'loanGuid', title: 'Encompass ID' },
                { data: 'fields.Loan\\.LoanNumber', title: 'Loan Number' },
                { data: 'fields.Loan\\.BorrowerName', title: 'Borrower' },
                { data: 'fields.Loan\\.LoanAmount', title: 'Loan Amount' },
                { data: 'fields.Fields\\.4000', title: 'Loan Type' }
            ],
            responsive: true,
            dom: 'Bfrtip',
            buttons: ['copy', 'csv', 'excel', 'pdf', 'print']
        });
    }

    // Click handlers
    _addNasaClickHandler() {
        $('#nasaTable tbody').on('click', 'tr', (event) => {
            const data = this.nasaTable.row(event.currentTarget).data();
            this._handleRowSelection(this.nasaTable, event.currentTarget);
            this._updateMapForNasaData(data);
        });
    }

    _addFemaClickHandler() {
        $('#femaTable tbody').on('click', 'tr', (event) => {
            const data = this.femaTable.row(event.currentTarget).data();
            this._handleRowSelection(this.femaTable, event.currentTarget);
            this._updateMapForFemaData(data);
        });
    }

    _addLoanClickHandler() {
        $('#loanTable tbody').on('click', 'tr', (event) => {
            const data = this.loanTable.row(event.currentTarget).data();
            this._handleRowSelection(this.loanTable, event.currentTarget);
            this._updateMapForLoanData(data);
        });
    }

    // Helper methods for map updates and row selection
    _handleRowSelection(table, row) {
        if ($(row).hasClass('selected')) {
            $(row).removeClass('selected');
        } else {
            table.$('tr.selected').removeClass('selected');
            $(row).addClass('selected');
        }
    }

    _updateMapForNasaData(data) {
        const location = {
            lat: parseFloat(data.latitude),
            lng: parseFloat(data.longitude)
        };
        this._updateMap(location, 12, {
            title: `Fire: ${data.county}, ${data.state}`,
            icon: {
                path: google.maps.SymbolPath.CIRCLE,
                scale: 8,
                fillColor: '#FF0000',
                fillOpacity: 0.7,
                strokeWeight: 1
            }
        });
        this._searchYouTube(`wildfire ${data.county} ${data.state}`, location.lat, location.lng);
    }

    _updateMapForFemaData(data) {
        const address = `${data.designatedArea.replace(/\s*\(County\)/i, '')} County, ${data.state}, USA`;
        this.geocoder.geocode({ address }, (results, status) => {
            if (status === 'OK') {
                const location = results[0].geometry.location;
                this._updateMap(location, 10, {
                    title: `${data.designatedArea}, ${data.state}`
                });
                this._searchYouTube(
                    `${data.incidentType} disaster ${data.designatedArea}`,
                    location.lat(),
                    location.lng()
                );
                this._updateLoanSection(data);
            }
        });
    }

    _updateMapForLoanData(data) {
        const address = `${data.fields["Fields.11"]}, ${data.fields["Fields.12"]}, ${data.fields["Fields.14"]}`;
        this.geocoder.geocode({ address }, (results, status) => {
            if (status === 'OK') {
                const location = results[0].geometry.location;
                this._updateMap(location, 10, {
                    title: `Loan: ${data.fields["Loan.LoanNumber"]}`,
                    icon: {
                        path: google.maps.SymbolPath.CIRCLE,
                        scale: 8,
                        fillColor: '#0000FF',
                        fillOpacity: 0.7,
                        strokeWeight: 1
                    }
                });
                this._fetchEncompassDetails(data.loanGuid);
            }
        });
    }

    _updateMap(location, zoom, markerOptions) {
        map.setCenter(location);
        map.setZoom(zoom);
        
        if (this.currentMarker) {
            this.currentMarker.setMap(null);
        }
        
        this.currentMarker = new google.maps.Marker({
            position: location,
            map: map,
            ...markerOptions
        });
    }

    _searchYouTube(query, lat, lng, radius = '50mi') {
        if (!window.youtubeAPIReady) {
            console.log('YouTube API not yet ready');
            return;
        }

        gapi.client.youtube.search.list({
            part: 'snippet',
            q: query,
            type: 'video',
            maxResults: 5,
            location: lat && lng ? `${lat},${lng}` : undefined,
            locationRadius: lat && lng ? radius : undefined
        })
        .then(response => {
            const results = response.result.items;
            this._displayYouTubeResults(results);
        })
        .catch(error => console.error('YouTube API error:', error));
    }

    _displayYouTubeResults(videos) {
        const videoContainer = document.getElementById('youtubeVideos');
        
        if (!videos || videos.length === 0) {
            videoContainer.innerHTML = `
                <h4>No Videos Found</h4>
                <div class="placeholder-container" style="height: calc(100% - 40px); display: flex; justify-content: center; align-items: center; background-color: #f8f9fa;">
                    <img src="assets/disaster-placeholder.jpg" alt="No videos found" style="max-width: 80%; max-height: 80%; object-fit: contain;">
                </div>
            `;
            return;
        }

        videoContainer.innerHTML = `
            <h4>Related Videos</h4>
            <div class="row video-container" style="height: calc(100% - 40px); overflow-y: auto;">
                ${videos.map(video => `
                    <div class="col-12 mb-3">
                        <div class="card">
                            <div class="row g-0">
                                <div class="col-md-4">
                                    <img src="${video.snippet.thumbnails.medium.url}" 
                                         class="img-fluid rounded-start" 
                                         alt="${video.snippet.title}">
                                </div>
                                <div class="col-md-8">
                                    <div class="card-body">
                                        <h5 class="card-title">${video.snippet.title}</h5>
                                        <p class="card-text">${video.snippet.description.substring(0, 100)}...</p>
                                        <a href="https://www.youtube.com/watch?v=${video.id.videoId}" 
                                           target="_blank" 
                                           class="btn btn-primary">Watch Video</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                `).join('')}
            </div>
        `;
    }

    _updateLoanSection(data) {
        this.selectedDisasterInfo = {
            name: data.declarationTitle,
            startDate: data.incidentBeginDate,
            endDate: data.incidentEndDate || 'Ongoing',
            county: data.designatedArea.replace(/\s*\(County\)/i, ''),
            state: data.state
        };

        const disasterInfoDiv = document.createElement('div');
        disasterInfoDiv.innerHTML = `
            <div class="selected-disaster-info mb-3">
                <h5>Selected Disaster:</h5>
                <p><strong>Name:</strong> ${this.selectedDisasterInfo.name}</p>
                <p><strong>Start Date:</strong> ${this.selectedDisasterInfo.startDate}</p>
                <p><strong>End Date:</strong> ${this.selectedDisasterInfo.endDate}</p>
                <p><strong>County:</strong> ${this.selectedDisasterInfo.county}</p>
                <p><strong>State:</strong> ${this.selectedDisasterInfo.state}</p>
            </div>
        `;

        const femaTableContainer = document.querySelector('#femaTable').parentElement;
        const existingInfo = femaTableContainer.querySelector('.selected-disaster-info');
        if (existingInfo) {
            existingInfo.remove();
        }
        femaTableContainer.insertBefore(disasterInfoDiv, femaTableContainer.firstChild);

        document.querySelector('#loanCollapse').classList.add('show');
    }

    async _fetchEncompassDetails(loanGuid) {
        try {
            const response = await fetch(`/api/${loanGuid}`);
            const encompassData = await response.json();
            this._displayEncompassDetails(encompassData);
        } catch (error) {
            console.error('Error fetching Encompass data:', error);
        }
    }

    _displayEncompassDetails(encompassData) {
        const encompassDetailsDiv = document.getElementById('encompassDetails') || 
            this._createEncompassDetailsDiv();
        
        encompassDetailsDiv.innerHTML = `
            <div class="card mt-3">
                <div class="card-header">
                    <h5>Encompass Loan Details</h5>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6">
                            <p><strong>Loan GUID:</strong> ${encompassData.loanGuid}</p>
                            <p><strong>Borrower Name:</strong> ${encompassData.borrowerName || 'N/A'}</p>
                            <p><strong>Loan Amount:</strong> ${this._formatCurrency(encompassData.loanAmount)}</p>
                        </div>
                        <div class="col-md-6">
                            <p><strong>Loan Status:</strong> ${encompassData.loanStatus || 'N/A'}</p>
                            <p><strong>Property Type:</strong> ${encompassData.propertyType || 'N/A'}</p>
                            <p><strong>Loan Officer:</strong> ${encompassData.loanOfficer || 'N/A'}</p>
                        </div>
                    </div>
                </div>
            </div>
        `;
    }

    _createEncompassDetailsDiv() {
        const div = document.createElement('div');
        div.id = 'encompassDetails';
        document.querySelector('#loanTable').parentNode.insertBefore(
            div, 
            document.querySelector('#loanTable').nextSibling
        );
        return div;
    }

    _formatCurrency(amount) {
        if (!amount) return '$0.00';
        return new Intl.NumberFormat('en-US', {
            style: 'currency',
            currency: 'USD'
        }).format(amount);
    }

    getSelectedDisasterInfo() {
        return this.selectedDisasterInfo;
    }
} 