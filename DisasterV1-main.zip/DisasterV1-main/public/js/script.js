let map;
let dbLoader = new DatabaseLoader();
window.youtubeAPIReady = false;

// Initialize map
function initMap() {
    map = new google.maps.Map(document.getElementById('map'), {
        center: { lat: 39.8283, lng: -98.5795 },
        zoom: 4
    });
    
    // Initialize DatabaseLoader with map
    dbLoader.initialize(map);
    
    // Add event listeners
    setupEventListeners();
}

function setupEventListeners() {
    // NASA Data
    const nasaButton = document.querySelector('#fetchNasaData');
    if (nasaButton) {
        nasaButton.addEventListener('click', async () => {
            console.log('Fetching NASA data...');
            await dbLoader.loadNasaData();
        });
    }

    // FEMA Data
    const femaButton = document.querySelector('#fetchFemaData');
    if (femaButton) {
        femaButton.addEventListener('click', async () => {
            console.log('Fetching FEMA data...');
            await dbLoader.loadFemaData();
        });
    }

    // Loan Data
    const loanButton = document.querySelector('#fetchLoanData');
    if (loanButton) {
        loanButton.addEventListener('click', async () => {
            console.log('Fetching Loan data...');
            const disasterInfo = dbLoader.getSelectedDisasterInfo();
            if (disasterInfo) {
                await dbLoader.loadLoanData(disasterInfo.state, disasterInfo.county);
            } else {
                console.log('No disaster selected');
            }
        });
    }
}

// Load Google Maps API
async function loadGoogleMaps() {
    try {
        const response = await fetch('/config');
        const config = await response.json();
        
        const script = document.createElement('script');
        script.src = `https://maps.googleapis.com/maps/api/js?key=${config.GOOGLE_MAPS_API_KEY}&callback=initMap`;
        script.async = true;
        script.defer = true;
        document.head.appendChild(script);
    } catch (error) {
        console.error('Error loading Google Maps:', error);
    }
}

function loadYouTubeAPI() {
    gapi.load('client', async () => {
        try {
            const response = await fetch('/api/config/youtube-key');
            const { key } = await response.json();
            
            await gapi.client.init({
                apiKey: key,
                discoveryDocs: ['https://www.googleapis.com/discovery/v1/apis/youtube/v3/rest']
            });
            window.youtubeAPIReady = true;
            console.log('YouTube API loaded successfully');
        } catch (error) {
            console.error('Error loading YouTube API:', error);
        }
    });
}

function createYouTubePlaceholder() {
    let videoContainer = document.getElementById('youtubeVideos');
    if (!videoContainer) {
        videoContainer = document.createElement('div');
        videoContainer.id = 'youtubeVideos';
        videoContainer.className = 'mt-3';
        videoContainer.style.height = '500px';
        
        videoContainer.innerHTML = `
            <h4>Disaster-Related Videos</h4>
            <div class="placeholder-container" style="height: calc(100% - 40px); display: flex; justify-content: center; align-items: center; background-color: #f8f9fa;">
                <img src="disasterManagement.png" alt="Select a disaster to view related videos" style="max-width: 80%; max-height: 80%; object-fit: contain;">
            </div>
        `;
        
        document.querySelector('#map').parentElement.nextElementSibling.appendChild(videoContainer);
    }
}

// Initialize everything
document.addEventListener('DOMContentLoaded', async function() {
    console.log('DOM Content Loaded');
    await loadGoogleMaps();
    loadYouTubeAPI();
    createYouTubePlaceholder();
});