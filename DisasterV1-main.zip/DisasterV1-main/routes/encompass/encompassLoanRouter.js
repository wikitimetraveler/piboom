const express = require('express');
const router = express.Router();
const EncompassLoanService = require('../../services/encompass/EncompassLoanService');

router.get('/loans/:loanGuid', async (req, res) => {
    try {
        const loanGuid = req.params.loanGuid;
        const loanService = new EncompassLoanService();
        const loanDetails = await loanService.getLoanById(loanGuid);
        res.json(loanDetails);
    } catch (error) {
        console.error('Error fetching loan details:', error);
        res.status(500).json({ error: error.message });
    }
});

module.exports = router; 