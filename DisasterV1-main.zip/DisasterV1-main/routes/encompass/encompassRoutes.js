const express = require('express');
const router = express.Router();
const { getLoansByCounty } = require('../../services/encompass/encompassService');

router.get('/loans/:state/:counties', async (req, res) => {
    try {
        const { state, counties } = req.params;
        const loans = await getLoansByCounty(state, counties);
        res.json(loans);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

module.exports = router; 