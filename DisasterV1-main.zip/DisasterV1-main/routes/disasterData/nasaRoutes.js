const express = require('express');
const router = express.Router();
const { getFirmsData } = require('../../services/disasterData/nasaService');

router.get('/firms-data', async (req, res) => {
    try {
        const data = await getFirmsData();
        res.send(data); // Send raw CSV data
    } catch (error) {
        console.error('Error in NASA firms-data route:', error);
        res.status(500).json({ error: 'Failed to fetch FIRMS data' });
    }
});

module.exports = router;