const express = require('express');
const router = express.Router();
const { getFemaDisasters } = require('../../services/disasterData/femaService');

router.get('/fema-disasters', async (req, res) => {
    try {
        const femaData = await getFemaDisasters();
        res.json(femaData);
    } catch (error) {
        res.status(500).json({ error: 'Error fetching FEMA disaster data' });
    }
});

module.exports = router;