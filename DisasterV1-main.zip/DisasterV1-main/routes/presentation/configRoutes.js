const express = require('express');
const router = express.Router();
require('dotenv').config();

router.get('/youtube-key', (req, res) => {
    res.json({ key: process.env.YOUTUBE_API_KEY });
});

module.exports = router; 