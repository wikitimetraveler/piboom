const express = require('express');
const router = express.Router();
const path = require('path');

// Import all routes
const femaRoutes = require('./disasterData/femaRoutes');
const encompassRoutes = require('./encompass/encompassRoutes');
const nasaRoutes = require('./disasterData/nasaRoutes');
const youtubeRoutes = require('./presentation/youtubeRoutes');
const configRoutes = require('./presentation/configRoutes');
const encompassLoanRoutes = require('./encompass/encompassLoanRouter');
const { EncompassLoanService } = require('../services/encompass/encompassLoanService');

// Mount all routes
router.use('/api', nasaRoutes);
router.use('/api', femaRoutes);
router.use('/api', encompassRoutes);
router.use('/api', encompassLoanRoutes);
router.use('/api', youtubeRoutes);
router.use('/api/config', configRoutes);

// Config endpoint for Google Maps API key
router.get('/config', (req, res) => {
    res.json({
        GOOGLE_MAPS_API_KEY: process.env.GOOGLE_MAPS_API_KEY
    });
});



module.exports = router; 