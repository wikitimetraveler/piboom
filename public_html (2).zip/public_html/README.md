Tech Stack:
Frontend: HTML5, CSS3, JavaScript (ES6+)
UI Framework: Bootstrap 4.5.2
Styling: Custom CSS with CSS Variables, animations, and glow effects
Icons: Bootstrap Icons
Libraries: jQuery 3.5.1, Popper.js

Backend: Node.js with Express.js
Database: PostgreSQL
Automation: Cron jobs for data processing
Data Sources: Encompass loan data via APIs and loan objects, NASA , FEMA Datasets
Accessibility: Speech enablement and voice control capabilities
Hosting: Local IIS server (localhost) - Rendor via Github

Coding Level Assessment:
Intermediate to Advanced Full-Stack Developer

Strengths:
Modern CSS: You're using CSS custom properties (variables), advanced animations, and complex visual effects
Responsive Design: Bootstrap implementation with custom styling
JavaScript: OO and Functional programming, DOM manipulation, event handling
UI/UX: Attention to visual details (glow effects, animations, dark mode)
Project Structure: Well-organized with separate tools/modules
Real-world Application: Building practical tools (FHA calculator, parsers, etc.)
Backend Integration: Node.js/Express API development
Database Management: PostgreSQL schema design and data modeling
Automation: Cron job implementation for data processing
API Integration: Encompass loan data integration via APIs and loan objects
Accessibility: Speech recognition and voice control implementation

Evidence of Advanced Skills:
Complex CSS animations with keyframes
Custom CSS variables for theming
Modular code organization
Professional UI with attention to accessibility
Real-world business logic implementation
Full-stack development capabilities
Database design and management
API development and integration
Automated data processing workflows
Speech recognition and voice control integration
