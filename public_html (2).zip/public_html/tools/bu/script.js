document.getElementById('searchButton').addEventListener('click', async () => {
    let state = document.getElementById('state').value;
    let county = document.getElementById('county').value;

    if (state && county) {
        // FEMA API URL and filtering logic
        let femaDisasterDeclUrl = 'https://www.fema.gov/api/open/v2/DisasterDeclarationsSummaries';
        let filterParams = `$count=true&$filter=state eq '${state}' and designatedArea eq '${county} (County)'`;

        try {
            let response = await fetch(`${femaDisasterDeclUrl}?${filterParams}`);
            let disasterDeclResults = await response.json();

            // Current timestamp
            let currentTimestamp = new Date();
            document.getElementById('searchTimestamp').innerText = 'Last Search Performed At: ' + currentTimestamp.toLocaleString();

            // Clear any existing data
            let tableBody = document.querySelector('#disasterTable tbody');
            tableBody.innerHTML = '';

            if (disasterDeclResults.metadata.count > 0) {
                // Populate the table
                disasterDeclResults.DisasterDeclarationsSummaries.forEach(item => {
                    let row = document.createElement('tr');
                    row.innerHTML = `
                        <td>${item.declarationType}</td>
                        <td>${item.incidentType}</td>
                        <td>${item.declarationTitle}</td>
                        <td>${item.ihProgramDeclared ? 'Yes' : 'No'}</td>
                        <td>${item.iaProgramDeclared ? 'Yes' : 'No'}</td>
                        <td>${item.paProgramDeclared ? 'Yes' : 'No'}</td>
                        <td>${item.hmProgramDeclared ? 'Yes' : 'No'}</td>
                        <td>${item.incidentBeginDate}</td>
                        <td>${item.incidentEndDate ? item.incidentEndDate : 'Ongoing'}</td>
                        <td>${item.disasterCloseoutDate || 'N/A'}</td>
                    `;
                    tableBody.appendChild(row);
                });

                // Initialize DataTable
                $('#disasterTable').DataTable({
                    order: [[7, 'asc'], [8, 'asc']], // Sort by incidentBeginDate and then incidentEndDate
                    destroy: true, // Re-initialize if table already exists
                });

            } else {
                alert('No disasters found for the specified area.');
            }
        } catch (error) {
            console.error('Error fetching FEMA data:', error);
        }
    } else {
        alert('Please enter both state and county.');
    }
});
