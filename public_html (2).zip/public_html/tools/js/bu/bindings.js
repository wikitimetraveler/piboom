/*
 Screen Binding Class
  Author: David Lane
  Date: November 14, 2023
  Purpose: Provide binding for any HTML page and ICE loan object
  Standalone: Yes
*/
class ScreenBindings {
    constructor() {
      // Initialize any properties here
      this.loanObject = null;
    }

async bindFieldValues() {
      if (elli && elli.script) {
           elli.script.subscribe("loan", "change", onLoanChange);
        elli.script.guest.create("", document.head);
        elli.script.subscribe("loan","change", function(loan) {
console.log("The loan has changed!")
});


 // Register the callback with the event
async function onLoanChange(Loan, changeset) {
 
  console.log("hello");
 };
        this.loanObject = await elli.script.getObject("loan");
        // Retrieve and bind field values
        const inputElementsWithEmid = document.querySelectorAll("input[emid]");
        const emidValues = [];
  
        inputElementsWithEmid.forEach((inputElement) => {
          const emid = inputElement.getAttribute("emid");
          this.loanObject.getField(emid).then((val) => {
            console.log(`FieldId ${emid} has value: ${val}`);
            inputElement.value = val;
            inputElement.setAttribute("changedvalue", "N");
            const inputValue = inputElement.value;
            inputElement.addEventListener("change", this.handleChange);
            emidValues.push({ emid, inputValue });
          });
        });
  
        console.log(
          "List of input elements with emid attribute and their values:",
          emidValues
        );
      }
    }
  
    processLoanObject() {
      if (!this.loanObject) {
        console.error("Loan object is not available.");
        return;
      }
  
      // Get all input elements with the "changedvalue" and "emid" attributes
      const inputElements = document.querySelectorAll(
        'input[changedvalue="Y"][emid]'
      );
  
      // Create a mapping of emid attributes to their values
      const emidToValueMap = {};
  
      inputElements.forEach((input) => {
        const emid = input.getAttribute("emid");
        const value = input.value;
        emidToValueMap[emid] = value;
        input.setAttribute("changedvalue", "N");
      });
  
      // Do something with the emidToValueMap and loanobject here
      this.loanObject.setFields(emidToValueMap);
      // Used to sync the 
    this.loanObject.merge();
    this.loanObject.calculate();
    }
  
    handleChange(event) {
      const change = event.target.getAttribute("changedvalue");
      const newValue = event.target.value;
      console.log(
        `Input with attribute changedvalue ${change} changed to: ${newValue}`
      );
  
      // Set the 'changed' attribute to 'Y' when the input changes
      event.target.setAttribute("changedvalue", "Y");
    }
    generateElements() {
        // Get the input values from the textarea
        var inputText = document.getElementById('inputValues').value;
    
        // Split the input text into lines
        var lines = inputText.split('\n');
    
        // Initialize an empty HTML string to store the generated elements
        var htmlOutput = '';
    
        // Loop through each line and create elements if square brackets are found
        lines.forEach(function (line) {
            var matches = line.match(/\[(.*?)\]/g);
            if (matches) {
                matches.forEach(function (match) {
                    // Remove square brackets and whitespace from the match
                    var value = match.replace(/\[|\]|\s/g, '');
                    // Create a label and input element with emid attribute
                    htmlOutput += '<label for="' + value + '">Label for ' + value + ': </label>';
                    htmlOutput += '<input type="text" id="' + value + '" name="' + value + '" emid="' + value + '">';
                    htmlOutput += '<br>';
                });
            }
        });
    
        // Display the generated elements in the outputElements div
        document.getElementById('outputElements').innerHTML = htmlOutput;
    }
    // Define an event handler function to run when the event occurs
    
  }
  
