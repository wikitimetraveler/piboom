
/*
  Author: David Lane
  Date: November 14, 2023
  Purpose: calculation for FHA Streamlien
*/
class FhaStreamlineCalculations {
  constructor(config) {
      this.groups = config.groups;
      this.initializeGroups();
  }

  initializeGroups() {
      this.groups.forEach(group => {
          const inputs = group.inputIds.map(id => document.getElementById(id));
          const result = document.getElementById(group.resultId);

          this.addEventListeners(inputs, () => this[group.calculation](inputs, result));
      });
  }

  addEventListeners(inputs, callback) {
      inputs.forEach(input => {
          input.addEventListener('input', callback);
      });
  }
 // make sure recalculated when output in also used as input in our calulations
  recalculateAll() {
      this.groups.forEach(group => {
          const inputs = group.inputIds.map(id => document.getElementById(id));
          const result = document.getElementById(group.resultId);

          this.updateResult(group.calculation, inputs, result);
      });
  }

  updateResult(calculation, inputs, result) {
      if (typeof this[calculation] === 'function') {
          this[calculation](inputs, result);
      }
  }

  sumInputs(inputs, result) {
      const values = inputs.map(input => parseFloat(input.value) || 0);
      const total = values.reduce((acc, currentValue) => acc + currentValue, 0);

      result.value = total;
  }

  minInputs(inputs, result) {
      const min = Math.min(...inputs.map(input => parseFloat(input.value) || 0));

       result.value = min;
  }
  // Add more update functions as needed
}

// Usage
const calculatorConfig = {
  groups: [
      {
          inputIds: ['calcA1_id', 'calcA2_id', 'calcA3_id', 'calcA4_id', 'calcA5_id'],
          resultId: 'calcA_result_id',
          calculation: 'sumInputs'
      },
      {
          inputIds: ['calcA_result_id', 'calcB2_id'],
          resultId: 'calcB_result_id',
          calculation: 'minInputs'
          // Add more groups as needed
      }
  ]
};
