/*
  Author: David Lane
  Date: November 14, 2023
  Purpose:   main starting point (DOM loaded)
*/
let loanObject = [];  // add for scope 
 // Create an instance of the ScreenBindings class and bind values from database
 const screenBindings = new ScreenBindings();
 const fhaStreamlineCalculator = new FhaStreamlineCalculations(calculatorConfig);


document.addEventListener("DOMContentLoaded", function () 
{
     // make sure recalculated when output in also used as input in our calulations
   document.querySelectorAll('.calculator-input').forEach(input => {
      input.addEventListener('input', () => fhaStreamlineCalculator.recalculateAll());
    });
    
 
  // Bind field values

 screenBindings.bindFieldValues();
  const mergeChangedFields = document.getElementById("mergeChangedFieldsBtn");
  mergeChangedFields.addEventListener("click", () => {
  // Later, when you want to process the loan object
     screenBindings.processLoanObject();
  })
  // parse on button click
  const parseFields = document.getElementById("parseFieldsBtn");
  parseFields.addEventListener("click", () => {
  // Later, when you want to process the loan object
     screenBindings.generateElements();
     screenBindings.bindFieldValues2();
  })
  


});




